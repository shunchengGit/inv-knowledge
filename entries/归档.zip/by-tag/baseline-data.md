# baseline-data

- [BNP Paribas — SK海力士1Q26完整业绩简报（含财务细表）](entries/BNP-Paribas-SK海力士1Q26完整业绩简报-含财务细表.md) — Note
- [福耀玻璃2024年年报核心要点](entries/福耀玻璃2024年年报核心要点.md) — Reference
- [福耀玻璃2025年年报业绩概览](entries/福耀玻璃2025年年报业绩概览.md) — Reference
- [腾讯控股投资者关系页面 - 2026年Q1财报与股价数据](entries/腾讯控股投资者关系页面-2026年Q1财报与股价数据.md) — Reference
