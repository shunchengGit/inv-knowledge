# gds-holdings

- [万国数据 2026-Q2 业绩分析 - Macquarie Research](entries/万国数据-2026-Q2-业绩分析-Macquarie-Research.md) — Article
- [万国数据 研究报告 - Deutsche Bank (2026-05-21)](entries/万国数据-研究报告-Deutsche-Bank-2026-05-21.md) — Article
- [万国数据 研究报告 - JPMorgan (2026-05-21)](entries/万国数据-研究报告-JPMorgan-2026-05-21.md) — Article
