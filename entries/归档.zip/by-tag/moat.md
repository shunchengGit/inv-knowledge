# moat

- [台积电商业模式与护城河分析](entries/台积电商业模式与护城河分析.md) — Analysis
- [福耀玻璃深度分析："汽车强国"背后的"卖铲人](entries/福耀玻璃深度分析-汽车强国背后的卖铲人.md) — Analysis
- [福耀玻璃竞争壁垒与护城河分析](entries/福耀玻璃竞争壁垒与护城河分析.md) — Analysis
