# foundry

- [台积电商业模式与护城河分析](entries/台积电商业模式与护城河分析.md) — Analysis
