# sk-hynix

- [BNP Paribas — SK海力士 1Q26业绩点评：AI内存领导力增强，目标价上调至₩2,000,000](entries/BNP-Paribas-SK海力士-1Q26业绩点评-AI内存领导力增强-目标价上调至-2-000-000.md) — Article
- [BNP Paribas — SK海力士1Q26完整业绩简报（含财务细表）](entries/BNP-Paribas-SK海力士1Q26完整业绩简报-含财务细表.md) — Note
- [HSBC (5月) — SK海力士：DRAM价格再超预期，TP从180万大幅上调至290万韩元](entries/HSBC-5月-SK海力士-DRAM价格再超预期-TP从180万大幅上调至290万韩元.md) — Article
- [HSBC — SK海力士1Q26业绩点评：服务器需求超预期，维持Buy目标₩1,800,000](entries/HSBC-SK海力士1Q26业绩点评-服务器需求超预期-维持Buy目标-1-800-000.md) — Article
- [JPMorgan (5月) — SK海力士：LTA铺路新估值框架，目标价上调至₩3,000,000](entries/JPMorgan-5月-SK海力士-LTA铺路新估值框架-目标价上调至-3-000-000.md) — Article
- [JPMorgan — SK海力士 1Q26业绩wrap：DRAM/NAND涨价加速，维持OW目标₩1,800,000](entries/JPMorgan-SK海力士-1Q26业绩wrap-DRAM-NAND涨价加速-维持OW目标-1-800-000.md) — Article
- [Macquarie (5月) — SK海力士：惊人利润增长拖低PE，目标价上调至₩290万](entries/Macquarie-5月-SK海力士-惊人利润增长拖低PE-目标价上调至-290万.md) — Article
- [Macquarie — SK海力士：内存供不应求将持续，结构化短缺而非周期波动](entries/Macquarie-SK海力士-内存供不应求将持续-结构化短缺而非周期波动.md) — Article
- [Nomura — SK海力士1Q26业绩点评：业绩Beat，LTA铺路新估值框架，目标价₩2,340,000](entries/Nomura-SK海力士1Q26业绩点评-业绩Beat-LTA铺路新估值框架-目标价-2-340-000.md) — Article
