# sentiment

- [BofA邀请CRIC林波——端午后中国地产实地考察电话会议（2026-06-22）](entries/BofA邀请CRIC林波-端午后中国地产实地考察电话会议-2026-06-22.md) — Note
- [HSBC — SK海力士1Q26业绩点评：服务器需求超预期，维持Buy目标₩1,800,000](entries/HSBC-SK海力士1Q26业绩点评-服务器需求超预期-维持Buy目标-1-800-000.md) — Article
- [Macquarie — SK海力士：内存供不应求将持续，结构化短缺而非周期波动](entries/Macquarie-SK海力士-内存供不应求将持续-结构化短缺而非周期波动.md) — Article
- [UBS — 微软与OpenAI修订协议点评：消除AGI条款是积极变化](entries/UBS-微软与OpenAI修订协议点评-消除AGI条款是积极变化.md) — Article
- [福耀玻璃6月18日两融数据：融资余额21.41亿元](entries/福耀玻璃6月18日两融数据-融资余额21-41亿元.md) — Article
- [福耀玻璃6月18日收盘与资金流：主力净流出3531.39万元](entries/福耀玻璃6月18日收盘与资金流-主力净流出3531-39万元.md) — Article
- [福耀玻璃H股6月17日南向资金减持12.28万股](entries/福耀玻璃H股6月17日南向资金减持12-28万股.md) — Article
