# microsoft

- [BNP Paribas — 微软与OpenAI调整合作协议：失去API独占权但消除AGI条款不确定性](entries/BNP-Paribas-微软与OpenAI调整合作协议-失去API独占权但消除AGI条款不确定性.md) — Article
- [BNP — OpenAI(Anthropic)效应：AI基础设施的机会与挑战](entries/BNP-OpenAI-Anthropic-效应-AI基础设施的机会与挑战.md) — Article
- [BNP — 微软FQ3'26财报点评：Azure与M365稳健，云竞赛白热化](entries/BNP-微软FQ3-26财报点评-Azure与M365稳健-云竞赛白热化.md) — Article
- [BNP — 微软：多线推进，Copilot开始拉动增长](entries/BNP-微软-多线推进-Copilot开始拉动增长.md) — Article
- [HSBC — Anthropic可能是微软430亿美元年运营机会](entries/HSBC-Anthropic可能是微软430亿美元年运营机会.md) — Article
- [HSBC — 微软FQ3'26强劲，Azure加速，维持Buy](entries/HSBC-微软FQ3-26强劲-Azure加速-维持Buy.md) — Article
- [Morgan Stanley — 微软Windows PC与NVIDIA合作开启AI PC时代](entries/Morgan-Stanley-微软Windows-PC与NVIDIA合作开启AI-PC时代.md) — Article
- [Morgan Stanley — 微软基础设施货币化：AI周期仍处早期](entries/Morgan-Stanley-微软基础设施货币化-AI周期仍处早期.md) — Article
- [UBS — 微软Capex加速、Azure增长加速、定价权提升](entries/UBS-微软Capex加速-Azure增长加速-定价权提升.md) — Article
- [UBS — 微软与OpenAI修订协议点评：消除AGI条款是积极变化](entries/UBS-微软与OpenAI修订协议点评-消除AGI条款是积极变化.md) — Article
