# risk-factor

- [BNP Paribas — 微软与OpenAI调整合作协议：失去API独占权但消除AGI条款不确定性](entries/BNP-Paribas-微软与OpenAI调整合作协议-失去API独占权但消除AGI条款不确定性.md) — Article
- [福耀玻璃2026年Q1汇兑风险深度分析](entries/福耀玻璃2026年Q1汇兑风险深度分析.md) — Analysis
