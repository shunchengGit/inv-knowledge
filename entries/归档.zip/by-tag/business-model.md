# business-model

- [BNP Paribas — 微软与OpenAI调整合作协议：失去API独占权但消除AGI条款不确定性](entries/BNP-Paribas-微软与OpenAI调整合作协议-失去API独占权但消除AGI条款不确定性.md) — Article
- [UBS — 微软与OpenAI修订协议点评：消除AGI条款是积极变化](entries/UBS-微软与OpenAI修订协议点评-消除AGI条款是积极变化.md) — Article
- [台积电商业模式与护城河分析](entries/台积电商业模式与护城河分析.md) — Analysis
- [福耀玻璃深度分析："汽车强国"背后的"卖铲人](entries/福耀玻璃深度分析-汽车强国背后的卖铲人.md) — Analysis
