# valuation

- [BNP Paribas — SK海力士 1Q26业绩点评：AI内存领导力增强，目标价上调至₩2,000,000](entries/BNP-Paribas-SK海力士-1Q26业绩点评-AI内存领导力增强-目标价上调至-2-000-000.md) — Article
- [HSBC (5月) — SK海力士：DRAM价格再超预期，TP从180万大幅上调至290万韩元](entries/HSBC-5月-SK海力士-DRAM价格再超预期-TP从180万大幅上调至290万韩元.md) — Article
- [JPMorgan (5月) — SK海力士：LTA铺路新估值框架，目标价上调至₩3,000,000](entries/JPMorgan-5月-SK海力士-LTA铺路新估值框架-目标价上调至-3-000-000.md) — Article
- [Macquarie (5月) — SK海力士：惊人利润增长拖低PE，目标价上调至₩290万](entries/Macquarie-5月-SK海力士-惊人利润增长拖低PE-目标价上调至-290万.md) — Article
- [Macquarie — SK海力士：内存供不应求将持续，结构化短缺而非周期波动](entries/Macquarie-SK海力士-内存供不应求将持续-结构化短缺而非周期波动.md) — Article
- [Nomura — SK海力士1Q26业绩点评：业绩Beat，LTA铺路新估值框架，目标价₩2,340,000](entries/Nomura-SK海力士1Q26业绩点评-业绩Beat-LTA铺路新估值框架-目标价-2-340-000.md) — Article
- [中际旭创 研究报告 - BofA Global Research (2026-06-09)](entries/中际旭创-研究报告-BofA-Global-Research-2026-06-09.md) — Article
- [日月光投控 研究报告 - Nomura (2026-05-05)](entries/日月光投控-研究报告-Nomura-2026-05-05.md) — Article
- [泡泡玛特 产品分析 - Deutsche Bank](entries/泡泡玛特-产品分析-Deutsche-Bank.md) — Article
- [福耀玻璃2026年Q1业绩后五大外资研报综合摘要](entries/福耀玻璃2026年Q1业绩后五大外资研报综合摘要.md) — Synthesis
- [福耀玻璃2026年Q1业绩后外资研报综合摘要](entries/福耀玻璃2026年Q1业绩后外资研报综合摘要.md) — Synthesis
- [福耀玻璃2026年Q1汇兑风险深度分析](entries/福耀玻璃2026年Q1汇兑风险深度分析.md) — Analysis
- [福耀玻璃2026年一季报业绩分析](entries/2026-05-31-福耀玻璃2026年一季报业绩分析.md) — Analysis
- [腾讯控股2026年Q1业绩后15家券商研报综合摘要](entries/腾讯控股2026年Q1业绩后15家券商研报综合摘要.md) — Synthesis
- [贵州茅台 研究报告 - Jefferies (2026-04-27)](entries/贵州茅台-研究报告-Jefferies-2026-04-27.md) — Article
